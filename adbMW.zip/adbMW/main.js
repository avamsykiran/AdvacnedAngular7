class Contact {
    constructor() {
        this.contactID = 0;
        this.firstName = "";
        this.lastName = "";
        this.mobileNumber = "";
        this.alternateMobileNumber = "";
        this.mailId = "";
        this.organization = "";
        this.dob = "";
    }
}

let express = require('express');
let fs = require('fs');
let bp = require('body-parser');
let cors = require('cors');

let contacts = null;

const dataFileName = "data.json";

fs.readFile(dataFileName, (err, data) => {
    contacts = JSON.parse(data);
});

let app = express();

app.use(bp.urlencoded({ extended: true }));
app.use(bp.json());
app.use(cors());

app.get("/", (req, resp) => {
    resp.end("Hello! My AddressBook MW Server is ready..!");
});

saveData = () => {
    fs.writeFile(dataFileName, JSON.stringify(contacts), (err) => {
        console.log(err);
    });
};

saveDataAndRespond = (resp) => {
    fs.writeFile(dataFileName, JSON.stringify(contacts), (err) => {
        if (!err) {
            resp.status(200);
            resp.end();
        } else {
            resp.status(500);
            resp.end();
            console.log(err);
        }
    });
}

app.get("/contacts", (req, resp) => {
    resp.send(contacts["contacts"]);
});

app.get("/contacts/:id", (req, resp) => {
    let cid = req.params.id;
    let contact = contacts["contacts"].find((c) => c.contactID == cid);
    if (contact == undefined) {
        resp.status(404);
        resp.end();
    } else {
        resp.send(contact);
    }
});

parseToContact = (req) => {
    let contact = new Contact();
    contact.contactID = req.body.contactID;
    contact.firstName = req.body.firstName;
    contact.lastName = req.body.lastName;
    contact.mobileNumber = req.body.mobileNumber;
    contact.organization = req.body.organization;
    contact.mailId = req.body.mailId;
    return contact;
}

app.post("/contacts", (req, resp) => {
    let contact = parseToContact(req);
    contacts["contacts"].push(contact);
    saveDataAndRespond(resp);
});

app.put("/contacts", (req, resp) => {
    let contact = parseToContact(req);

    let index = contacts["contacts"].findIndex((c) => c.contactID == contact.contactID);
    if (index > -1) {
        contacts["contacts"][index] = contact;
        saveDataAndRespond(resp);
    } else {
        resp.status(404);
        resp.end();
    }
});

app.delete("/contacts/:id", (req, resp) => {
    let index = contacts.findIndex((c) => c.contactID == id);
    if (index > -1) {
        contacts["contacts"].splice(index,1);
        saveDataAndRespond(resp);
    } else {
        resp.status(404);
        resp.end();
    }
});

app.listen(5454, () => {
    console.log("The server started successfully @ localhost:5454");
});