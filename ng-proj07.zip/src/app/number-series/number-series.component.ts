import { Component, OnInit } from '@angular/core';
import { NumberSeriesService } from '../number-series.service';

@Component({
  selector: 'app-number-series',
  templateUrl: './number-series.component.html',
  styleUrls: ['./number-series.component.css']
})
export class NumberSeriesComponent implements OnInit {

  lb:number=1;
  ub:number=100;
  enable:boolean=true;
  isEven:boolean=false;
  isSqrd:boolean=false;
  errMsg:string="";
  nums:number[]=[];

  constructor(private nss:NumberSeriesService) { }

  ngOnInit() {
  }

  startSeries(){
    this.enable=false;
    this.nums=[];
    this.errMsg="";

    let obrvbl = null;

    if(this.isEven&&this.isSqrd){
      obrvbl=this.nss.generateEvenSquaredSeries(this.lb,this.ub);
    }else if(this.isEven){
      obrvbl=this.nss.generateEvenSeries(this.lb,this.ub);
    }else if(this.isSqrd){
      obrvbl=this.nss.generateSquaredSeries(this.lb,this.ub);
    }else{
      obrvbl=this.nss.generateSeries(this.lb,this.ub);
    }

    obrvbl.subscribe(
      (n)=>{this.nums.push(n);},
      (err)=>{this.errMsg=err; this.enable=true;},
      ()=>{this.enable=true;}
    );
  }
}
