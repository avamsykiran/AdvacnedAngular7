import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes-demo',
  templateUrl: './pipes-demo.component.html',
  styleUrls: ['./pipes-demo.component.css']
})
export class PipesDemoComponent implements OnInit {

  title:string;

  strData:string;
  numData:number;
  dateData:Date;
  num:number;

  constructor() { }

  ngOnInit() {
    this.title="Pipes Demo";
    this.strData="This is a test string.";
    this.numData=12345.56789;
    this.dateData=new Date();
    this.num=123045;
  }

}
