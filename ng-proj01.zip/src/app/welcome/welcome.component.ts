import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  title:string;
  userName:string;
  dobString:string;
  age:number;

  constructor() { }

  ngOnInit() {
    this.title="Simple Form Element Data Binding";
    this.userName="";
    this.dobString="";
    this.age=0;
  }

  update(){
    let currentDate = new Date();
    let dob = new Date(this.dobString);
    this.age = currentDate.getFullYear()-dob.getFullYear();
  }

}
