import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'toWords'
})
export class ToWordsPipe implements PipeTransform {

  digits:string[] =[
    "ZERO",    "ONE",    "TWO",    "THREE",    "FOUR",
    "FIVE",    "SIX",    "SEVEN",    "EIGHT",    "NINE"
  ];

  transform(value: number, args?: any): string {
    let result:string="";

    let numStr = value+"";
    for(let i=0;i<numStr.length;i++){
      result += this.digits[parseInt(numStr.charAt(i))]+ " ";
    }

    return result;
  }

}
