export interface IConfig {
  adminName: string;
  permissions?: string[];
}
