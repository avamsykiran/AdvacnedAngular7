import { IUser } from '../user.interface';

export interface IUserHttp {
  users: IUser[];
}
