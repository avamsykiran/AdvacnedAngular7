# angular-ngrx

Angular: NGRX a clear Introduction
