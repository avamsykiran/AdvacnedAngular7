import { Injectable } from '@angular/core';
import { Contact } from '../models/contact';

@Injectable({
  providedIn: 'root'
})
export class ContactService {

  contacts:Contact[];

  constructor() { 
    this.contacts=[
      {contactID:101,firstName:"Vamsy",lastName:"Kiran",dob:new Date("1985-03-11"),mobileNumber:"9052224753",mailId:"vamsy.kiran@iiht.com",organization:"IIHT"},
      {contactID:102,firstName:"Shiilpa",lastName:"T",dob:new Date("1983-02-11"),mobileNumber:"9052124753",mailId:"shilpa@iiht.com",organization:"IIHT"},
      {contactID:103,firstName:"Dhamu",lastName:"G.L",dob:new Date("1982-03-11"),mobileNumber:"9054224753",mailId:"gl@iiht.com",organization:"IIHT"},
      {contactID:104,firstName:"Arun",lastName:"Sk.",dob:new Date("1987-04-11"),mobileNumber:"9052524753",mailId:"arun@cts.com",organization:"CTS"},
      {contactID:105,firstName:"Prasanth",lastName:"Vadipalli",dob:new Date("1986-11-11"),mobileNumber:"9052224753",mailId:"prasanth@cts.com",organization:"CTS"}
    ];
  }

  getAll():Contact[]{
    return this.contacts;
  }

  get(id:number){
    let index = this.contacts.findIndex((contact)=>(contact.contactID==id));
    return index>-1?this.contacts[index]:null;
  }

  add(contact:Contact){
    this.contacts.push(contact);
  }

  update(contact:Contact){
    let index= this.contacts.findIndex((c)=>(c.contactID===contact.contactID));
    if(index>-1){
      this.contacts[index]=contact;
    }
  }

  delete(id:number){
    let index= this.contacts.findIndex((contact)=>(contact.contactID===id));
    if(index>-1){
      this.contacts.splice(index,1);
    }
  }
}
