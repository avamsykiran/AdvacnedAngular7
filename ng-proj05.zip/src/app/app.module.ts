import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ContactsListComponent } from './contacts-list/contacts-list.component';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ContactDetailsComponent } from './contact-details/contact-details.component';
import { ContactsGridComponent } from './contacts-grid/contacts-grid.component';
import { ContactsGridItemComponent } from './contacts-grid-item/contacts-grid-item.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    ContactsListComponent,
    ContactFormComponent,
    PageNotFoundComponent,
    ContactDetailsComponent,
    ContactsGridComponent,
    ContactsGridItemComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
