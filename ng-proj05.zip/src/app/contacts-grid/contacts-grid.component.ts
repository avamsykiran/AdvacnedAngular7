import { Component, OnInit } from '@angular/core';
import { Contact } from '../models/contact';
import { ContactService } from '../services/contact.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-contacts-grid',
  templateUrl: './contacts-grid.component.html',
  styleUrls: ['./contacts-grid.component.css']
})
export class ContactsGridComponent implements OnInit {

  contacts: Contact[];

  constructor(private contSer: ContactService,private router:Router) { }

  ngOnInit() {
    this.contSer.getAll().subscribe(
      (data) => { this.contacts = data; }
    );
  }

  delete(id:number){
    this.contSer.delete(id).subscribe(
      ()=>{
        this.contSer.getAll().subscribe(
          (data) => { this.contacts = data; }
        );
      }
    );
  }

  edit(id:number){
    this.router.navigateByUrl(`/edit/${id}`);
  }

  detail(id:number){
    this.router.navigateByUrl(`/details/${id}`);
  }
}
