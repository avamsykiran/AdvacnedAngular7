import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactsGridItemComponent } from './contacts-grid-item.component';

describe('ContactsGridItemComponent', () => {
  let component: ContactsGridItemComponent;
  let fixture: ComponentFixture<ContactsGridItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContactsGridItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactsGridItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
