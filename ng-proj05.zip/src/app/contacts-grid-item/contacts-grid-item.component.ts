import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Contact } from '../models/contact';

@Component({
  selector: 'app-contacts-grid-item',
  templateUrl: './contacts-grid-item.component.html',
  styleUrls: ['./contacts-grid-item.component.css']
})
export class ContactsGridItemComponent implements OnInit {

  @Input() contact : Contact;

  @Output() detailEvent : EventEmitter<null>;
  @Output() editEvent : EventEmitter<null>;
  @Output() deleteEvent : EventEmitter<null>;

  constructor() {
    this.detailEvent = new EventEmitter();
    this.editEvent = new EventEmitter();
    this.deleteEvent = new EventEmitter();
   }

  ngOnInit() {
  }

  fireDetails(){
    this.detailEvent.emit();
  }
  fireEdit(){
    this.editEvent.emit();
  }
  fireDelete(){
    this.deleteEvent.emit();
  }
}
