import { Component, OnInit } from '@angular/core';
import { Contact } from '../models/contact';
import { ContactService } from '../services/contact.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.css']
})
export class ContactFormComponent implements OnInit {

  private contactForm: FormGroup;
  private isNew: boolean;

  constructor(private contServ: ContactService,
    private routeData: ActivatedRoute,
    private router: Router,
    private fb:FormBuilder
  ) {
    this.contactForm = this.fb.group({
      contactID: [0, [Validators.required]],
      firstName: ['', [Validators.required, Validators.minLength(5)]],
      lastName: ['', [Validators.required, Validators.minLength(5)]],
      mobileNumber: ['', [Validators.required]],
      alternateMobileNumber: ['', [Validators.required]],
      mailId: ['', [Validators.required]],
      organization: ['', [Validators.required]],
      dob: [new Date().toISOString().substr(0, 10), [Validators.required]]
    });
    /*this.contactForm = new FormGroup({
      contactID: new FormControl(0, [Validators.required]),
      firstName: new FormControl('', [Validators.required, Validators.minLength(5)]),
      lastName: new FormControl('', [Validators.required, Validators.minLength(5)]),
      mobileNumber: new FormControl('', [Validators.required]),
      alternateMobileNumber: new FormControl('', [Validators.required]),
      mailId: new FormControl('', [Validators.required]),
      organization: new FormControl('', [Validators.required]),
      dob: new FormControl(new Date().toISOString().substr(0, 10), [Validators.required])
    });*/
  }

  c(controlName: string) {
    return this.contactForm.controls[controlName];
  }

  ngOnInit() {
    this.routeData.params.subscribe(
      (params) => {
        let contactID = params['cid'];

        if (contactID == undefined) {
          this.isNew = true;
        } else {
          this.contServ.get(contactID).subscribe(
            (data) => {
              this.contactForm.controls.contactID.setValue(data.contactID);
              this.contactForm.controls.firstName.setValue(data.firstName);
              this.contactForm.controls.lastName.setValue(data.lastName);
              this.contactForm.controls.mobileNumber.setValue(data.mobileNumber);
              this.contactForm.controls.alternateMobileNumber.setValue(data.alternateMobileNumber);
              this.contactForm.controls.mailId.setValue(data.mailId);
              this.contactForm.controls.organization.setValue(data.organization);
              this.contactForm.controls.dob.setValue(data.dob);
            }
          );
        }
      }
    );
  }

  save() {
    if (this.isNew) {
      this.contServ.add(this.contactForm.value).subscribe(
        () => {
          this.router.navigateByUrl("/list");
        }
      );
    } else {
      this.contServ.update(this.contactForm.value).subscribe(
        () => {
          this.router.navigateByUrl("/list");
        }
      );
    }
  }
}
