import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GreetingService {

  constructor() { }

  getGreeting(h:number):string{
    let greeting=null;

    if(h>=3 && h<=11) greeting="Good Morning";
    else if(h>=12 && h<=19) greeting="Good Evening";
    else greeting="Good Night";

    return greeting;
  }
}
