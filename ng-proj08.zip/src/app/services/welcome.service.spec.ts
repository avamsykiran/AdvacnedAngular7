import { TestBed } from '@angular/core/testing';

import { WelcomeService } from './welcome.service';
import { GreetingService } from './greeting.service';

describe('WelcomeService', () => {
  let welcomeService: WelcomeService;
  let gs : GreetingService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GreetingService, WelcomeService]
    });
    welcomeService = TestBed.get(WelcomeService);
    gs = TestBed.get(GreetingService);
  });

  it('should be created', () => {
    expect(welcomeService).toBeTruthy();
  });

  it('should return proper greet note when getWelcomeNotte is called', () => {
    let greetSpy = spyOn(gs,'getGreeting').and.callThrough();

    expect(welcomeService.getWelcomeNote(10, 'Vamsy'))
      .toEqual('Good Morning Vamsy!');
    expect(welcomeService.getWelcomeNote(16, 'Vamsy'))
      .toEqual('Good Evening Vamsy!');
    expect(welcomeService.getWelcomeNote(23, 'Vamsy'))
      .toEqual('Good Night Vamsy!');
   
    expect(greetSpy).toHaveBeenCalled();
  });
});
