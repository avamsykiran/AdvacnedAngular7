import { TestBed } from '@angular/core/testing';

import { GreetingService } from './greeting.service';

describe('GreetingService', () => {
  let service: GreetingService;
  
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers:[GreetingService]
    });
    service = TestBed.get(GreetingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return greeting as per time',()=>{
    expect(service.getGreeting(10)).toEqual('Good Morning');
    expect(service.getGreeting(16)).toEqual('Good Evening');
    expect(service.getGreeting(22)).toEqual('Good Night');
  });
});
