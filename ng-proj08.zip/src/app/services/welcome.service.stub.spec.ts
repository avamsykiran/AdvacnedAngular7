
import { WelcomeService } from './welcome.service';

class FakeGreetingSerrvice{
  getGreeting(h:number):string{
    return "Hello";
  }
}

describe('WelcomeServiceStub', () => {
  let welcomeService: WelcomeService;
  let gs : FakeGreetingSerrvice;
  beforeEach(() => {    
    gs=new FakeGreetingSerrvice();
    welcomeService = new WelcomeService(gs);
  });

  it('should be created', () => {
    expect(welcomeService).toBeTruthy();
  });

  it('should return proper greet note when getWelcomeNotte is called', () => {
    let greetSpy = spyOn(gs,'getGreeting').and.callThrough();

    expect(welcomeService.getWelcomeNote(23, 'Vamsy'))
      .toEqual('Hello Vamsy!');
   
    expect(greetSpy).toHaveBeenCalled();
  });
});
