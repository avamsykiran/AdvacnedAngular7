import { Injectable } from '@angular/core';
import { GreetingService } from './greeting.service';

@Injectable({
  providedIn: 'root'
})
export class WelcomeService {

  constructor(private gs:GreetingService) {  }

  getWelcomeNote(h:number,userName:string):string{
    return `${this.gs.getGreeting(h)} ${userName}!`;
  }
}
