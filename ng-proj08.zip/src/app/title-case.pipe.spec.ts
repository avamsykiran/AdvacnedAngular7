import { TitleCasePipe } from './title-case.pipe';

describe('TitleCasePipe', () => {

  let p : TitleCasePipe;

  beforeEach(()=>{
    p = new TitleCasePipe();
  });
  it('create an instance', () => {
    expect(p).toBeTruthy();
  });

  it('should return TitleCase', () => {
    expect(p.transform('text')).toEqual('TitleCase');
  });
});
