import { TestBed, async } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { DummyComponent } from './dummy/dummy.component';

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent,DummyComponent
      ],
      providers:[
        
      ]
    }).compileComponents();
  }));

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'Testing Angular Demo'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.title).toEqual('Testing Angular Demo');
  });

  it('should render title in a h1 tag', () => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h2').textContent).toContain('TESTING ANGULAR DEMO');
    expect(compiled.querySelector('p').textContent).toContain('dummy works!');

    let btn = compiled.querySelector('#btn1');
    //btn.dispatchEvent(new Event('click'));
    btn.click();
    fixture.detectChanges();
    expect(fixture.componentInstance.title).toEqual("Changed");
    expect(compiled.querySelector('h2').textContent).toContain('CHANGED');
  });
});
